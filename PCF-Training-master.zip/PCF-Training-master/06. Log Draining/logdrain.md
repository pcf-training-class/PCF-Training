# Log Draining
